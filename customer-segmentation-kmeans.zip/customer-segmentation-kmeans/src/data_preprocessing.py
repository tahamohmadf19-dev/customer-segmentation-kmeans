"""
Data Preprocessing Module for Customer Segmentation

This module provides functions for cleaning and preparing retail transaction data
for RFM analysis and customer segmentation.

Author: Data Science Portfolio Project
License: MIT
"""

import pandas as pd
import numpy as np
from typing import Optional, Tuple


def load_data(filepath: str, encoding: str = 'latin1') -> pd.DataFrame:
    """
    Load retail transaction data from CSV file.
    
    Parameters
    ----------
    filepath : str
        Path to the CSV file containing transaction data.
    encoding : str, default='latin1'
        File encoding to use when reading the CSV.
    
    Returns
    -------
    pd.DataFrame
        Raw transaction data.
    
    Examples
    --------
    >>> df = load_data('data/online_retail_II.csv')
    >>> print(df.shape)
    (541910, 8)
    """
    df = pd.read_csv(filepath, encoding=encoding)
    print(f"Loaded {len(df):,} records with {df.shape[1]} columns")
    return df


def remove_missing_customers(df: pd.DataFrame, 
                              customer_col: str = 'Customer ID') -> pd.DataFrame:
    """
    Remove records with missing Customer IDs.
    
    Customer ID is essential for segmentation - records without it
    cannot be attributed to any customer.
    
    Parameters
    ----------
    df : pd.DataFrame
        Transaction data with potential missing Customer IDs.
    customer_col : str, default='Customer ID'
        Name of the customer identifier column.
    
    Returns
    -------
    pd.DataFrame
        Data with non-null Customer IDs only.
    """
    initial_count = len(df)
    df_clean = df.dropna(subset=[customer_col])
    removed = initial_count - len(df_clean)
    print(f"Removed {removed:,} records with missing {customer_col}")
    return df_clean


def filter_valid_transactions(df: pd.DataFrame,
                               quantity_col: str = 'Quantity',
                               price_col: str = 'Price') -> pd.DataFrame:
    """
    Filter out invalid transactions (returns, cancellations, errors).
    
    Removes records with:
    - Negative or zero quantity (returns/cancellations)
    - Negative or zero price (data errors)
    
    Parameters
    ----------
    df : pd.DataFrame
        Transaction data.
    quantity_col : str, default='Quantity'
        Name of the quantity column.
    price_col : str, default='Price'
        Name of the price column.
    
    Returns
    -------
    pd.DataFrame
        Data with valid transactions only.
    """
    initial_count = len(df)
    df_valid = df[(df[quantity_col] > 0) & (df[price_col] > 0)]
    removed = initial_count - len(df_valid)
    print(f"Removed {removed:,} invalid transactions (returns/errors)")
    return df_valid


def convert_date_column(df: pd.DataFrame,
                         date_col: str = 'InvoiceDate',
                         date_format: str = '%d-%m-%Y %H:%M') -> pd.DataFrame:
    """
    Convert date column to datetime type.
    
    Parameters
    ----------
    df : pd.DataFrame
        Transaction data.
    date_col : str, default='InvoiceDate'
        Name of the date column.
    date_format : str, default='%d-%m-%Y %H:%M'
        Expected date format string.
    
    Returns
    -------
    pd.DataFrame
        Data with datetime-converted date column.
    """
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col], format=date_format)
    print(f"Date range: {df[date_col].min()} to {df[date_col].max()}")
    return df


def calculate_total_price(df: pd.DataFrame,
                           quantity_col: str = 'Quantity',
                           price_col: str = 'Price',
                           total_col: str = 'TotalPrice') -> pd.DataFrame:
    """
    Calculate total transaction value (Quantity × Price).
    
    Parameters
    ----------
    df : pd.DataFrame
        Transaction data.
    quantity_col : str, default='Quantity'
        Name of the quantity column.
    price_col : str, default='Price'
        Name of the price column.
    total_col : str, default='TotalPrice'
        Name for the new total price column.
    
    Returns
    -------
    pd.DataFrame
        Data with added total price column.
    """
    df = df.copy()
    df[total_col] = df[quantity_col] * df[price_col]
    return df


def preprocess_retail_data(filepath: str,
                            encoding: str = 'latin1',
                            date_format: str = '%d-%m-%Y %H:%M') -> pd.DataFrame:
    """
    Complete preprocessing pipeline for retail transaction data.
    
    Applies all preprocessing steps in sequence:
    1. Load data
    2. Remove missing Customer IDs
    3. Filter invalid transactions
    4. Convert date column
    5. Calculate total price
    
    Parameters
    ----------
    filepath : str
        Path to the CSV file.
    encoding : str, default='latin1'
        File encoding.
    date_format : str, default='%d-%m-%Y %H:%M'
        Date format string.
    
    Returns
    -------
    pd.DataFrame
        Fully preprocessed transaction data.
    
    Examples
    --------
    >>> df = preprocess_retail_data('data/online_retail_II.csv')
    >>> print(df.shape)
    (397885, 9)
    """
    print("=" * 50)
    print("Starting Data Preprocessing Pipeline")
    print("=" * 50)
    
    # Load
    df = load_data(filepath, encoding)
    
    # Clean
    df = remove_missing_customers(df)
    df = filter_valid_transactions(df)
    
    # Transform
    df = convert_date_column(df, date_format=date_format)
    df = calculate_total_price(df)
    
    print("=" * 50)
    print(f"Preprocessing complete: {len(df):,} valid transactions")
    print("=" * 50)
    
    return df


def get_data_summary(df: pd.DataFrame) -> dict:
    """
    Generate summary statistics for the dataset.
    
    Parameters
    ----------
    df : pd.DataFrame
        Preprocessed transaction data.
    
    Returns
    -------
    dict
        Dictionary containing summary statistics.
    """
    summary = {
        'total_transactions': len(df),
        'unique_customers': df['Customer ID'].nunique(),
        'unique_products': df['StockCode'].nunique(),
        'date_range': (df['InvoiceDate'].min(), df['InvoiceDate'].max()),
        'total_revenue': df['TotalPrice'].sum(),
        'avg_transaction_value': df['TotalPrice'].mean(),
        'countries': df['Country'].nunique()
    }
    return summary


if __name__ == "__main__":
    # Example usage
    print("Data Preprocessing Module")
    print("Use: from data_preprocessing import preprocess_retail_data")
