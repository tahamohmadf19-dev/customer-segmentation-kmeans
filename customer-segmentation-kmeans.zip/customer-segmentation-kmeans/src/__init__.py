"""
Customer Segmentation Package

Modules:
- data_preprocessing: Functions for cleaning and preparing retail data
- rfm_analysis: RFM calculation and K-Means clustering functions
"""

from .data_preprocessing import (
    load_data,
    preprocess_retail_data,
    get_data_summary
)

from .rfm_analysis import (
    calculate_rfm,
    scale_features,
    find_optimal_clusters,
    segment_customers,
    predict_customer_segment,
    get_cluster_summary,
    export_segments
)

__version__ = '1.0.0'
__author__ = 'Data Science Portfolio'
