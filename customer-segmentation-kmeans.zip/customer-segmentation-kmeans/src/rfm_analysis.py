"""
RFM Analysis and Customer Segmentation Module

This module provides functions for RFM (Recency, Frequency, Monetary) analysis
and K-Means clustering for customer segmentation.

Author: Data Science Portfolio Project
License: MIT
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from typing import Tuple, Optional, List


def calculate_rfm(df: pd.DataFrame,
                  customer_col: str = 'Customer ID',
                  date_col: str = 'InvoiceDate',
                  invoice_col: str = 'Invoice',
                  monetary_col: str = 'TotalPrice',
                  reference_date: Optional[pd.Timestamp] = None) -> pd.DataFrame:
    """
    Calculate RFM (Recency, Frequency, Monetary) metrics for each customer.
    
    Parameters
    ----------
    df : pd.DataFrame
        Preprocessed transaction data.
    customer_col : str, default='Customer ID'
        Customer identifier column.
    date_col : str, default='InvoiceDate'
        Transaction date column.
    invoice_col : str, default='Invoice'
        Invoice/transaction identifier column.
    monetary_col : str, default='TotalPrice'
        Transaction value column.
    reference_date : pd.Timestamp, optional
        Reference date for recency calculation. If None, uses max date + 1 day.
    
    Returns
    -------
    pd.DataFrame
        DataFrame with Recency, Frequency, Monetary columns indexed by Customer ID.
    
    Examples
    --------
    >>> rfm = calculate_rfm(df)
    >>> print(rfm.head())
                 Recency  Frequency  Monetary
    Customer ID                              
    12346.0          326          1  77183.60
    12347.0            2          7   4310.00
    """
    # Set reference date
    if reference_date is None:
        reference_date = df[date_col].max() + pd.Timedelta(days=1)
    
    print(f"Reference date for Recency: {reference_date}")
    
    # Aggregate RFM metrics
    rfm = df.groupby(customer_col).agg({
        date_col: lambda x: (reference_date - x.max()).days,  # Recency
        invoice_col: 'nunique',                                # Frequency
        monetary_col: 'sum'                                    # Monetary
    })
    
    # Rename columns
    rfm.columns = ['Recency', 'Frequency', 'Monetary']
    
    print(f"RFM calculated for {len(rfm):,} customers")
    
    return rfm


def scale_features(rfm: pd.DataFrame,
                   scaler: Optional[StandardScaler] = None) -> Tuple[np.ndarray, StandardScaler]:
    """
    Scale RFM features using StandardScaler.
    
    Parameters
    ----------
    rfm : pd.DataFrame
        RFM DataFrame.
    scaler : StandardScaler, optional
        Pre-fitted scaler. If None, a new scaler is fitted.
    
    Returns
    -------
    Tuple[np.ndarray, StandardScaler]
        Scaled features array and the fitted scaler.
    """
    if scaler is None:
        scaler = StandardScaler()
        rfm_scaled = scaler.fit_transform(rfm)
        print("StandardScaler fitted and applied")
    else:
        rfm_scaled = scaler.transform(rfm)
        print("StandardScaler applied (pre-fitted)")
    
    return rfm_scaled, scaler


def find_optimal_clusters(rfm_scaled: np.ndarray,
                          k_range: range = range(2, 11),
                          random_state: int = 42) -> Tuple[List[float], List[float]]:
    """
    Find optimal number of clusters using Elbow Method and Silhouette Score.
    
    Parameters
    ----------
    rfm_scaled : np.ndarray
        Scaled RFM features.
    k_range : range, default=range(2, 11)
        Range of cluster numbers to evaluate.
    random_state : int, default=42
        Random state for reproducibility.
    
    Returns
    -------
    Tuple[List[float], List[float]]
        Lists of WCSS values and Silhouette scores.
    """
    wcss = []
    silhouette_scores = []
    
    print("Evaluating cluster counts...")
    print("-" * 40)
    
    for k in k_range:
        kmeans = KMeans(n_clusters=k, random_state=random_state, n_init=10)
        kmeans.fit(rfm_scaled)
        wcss.append(kmeans.inertia_)
        sil_score = silhouette_score(rfm_scaled, kmeans.labels_)
        silhouette_scores.append(sil_score)
        print(f"k={k}: WCSS={kmeans.inertia_:.2f}, Silhouette={sil_score:.4f}")
    
    return wcss, silhouette_scores


def plot_cluster_evaluation(k_range: range,
                            wcss: List[float],
                            silhouette_scores: List[float],
                            optimal_k: int = 4,
                            save_path: Optional[str] = None) -> None:
    """
    Plot Elbow Method and Silhouette Score charts.
    
    Parameters
    ----------
    k_range : range
        Range of cluster numbers evaluated.
    wcss : List[float]
        WCSS values for each k.
    silhouette_scores : List[float]
        Silhouette scores for each k.
    optimal_k : int, default=4
        Optimal k to highlight.
    save_path : str, optional
        Path to save the figure.
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # Elbow Plot
    axes[0].plot(list(k_range), wcss, 'bo-', linewidth=2, markersize=8)
    axes[0].axvline(x=optimal_k, color='red', linestyle='--', label=f'Optimal k={optimal_k}')
    axes[0].set_xlabel('Number of Clusters (k)', fontsize=11)
    axes[0].set_ylabel('WCSS', fontsize=11)
    axes[0].set_title('Elbow Method', fontsize=13, fontweight='bold')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    
    # Silhouette Plot
    axes[1].plot(list(k_range), silhouette_scores, 'go-', linewidth=2, markersize=8)
    axes[1].axvline(x=optimal_k, color='red', linestyle='--', label=f'Optimal k={optimal_k}')
    axes[1].set_xlabel('Number of Clusters (k)', fontsize=11)
    axes[1].set_ylabel('Silhouette Score', fontsize=11)
    axes[1].set_title('Silhouette Score Analysis', fontsize=13, fontweight='bold')
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Figure saved to {save_path}")
    
    plt.show()


def segment_customers(rfm: pd.DataFrame,
                      rfm_scaled: np.ndarray,
                      n_clusters: int = 4,
                      random_state: int = 42) -> Tuple[pd.DataFrame, KMeans]:
    """
    Apply K-Means clustering to segment customers.
    
    Parameters
    ----------
    rfm : pd.DataFrame
        RFM DataFrame.
    rfm_scaled : np.ndarray
        Scaled RFM features.
    n_clusters : int, default=4
        Number of clusters.
    random_state : int, default=42
        Random state for reproducibility.
    
    Returns
    -------
    Tuple[pd.DataFrame, KMeans]
        RFM DataFrame with Cluster column and fitted KMeans model.
    """
    kmeans = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
    rfm = rfm.copy()
    rfm['Cluster'] = kmeans.fit_predict(rfm_scaled)
    
    # Calculate silhouette score
    sil_score = silhouette_score(rfm_scaled, rfm['Cluster'])
    
    print(f"K-Means clustering complete (k={n_clusters})")
    print(f"Silhouette Score: {sil_score:.4f}")
    print(f"\nCluster Distribution:")
    print(rfm['Cluster'].value_counts().sort_index())
    
    return rfm, kmeans


def get_cluster_summary(rfm: pd.DataFrame) -> pd.DataFrame:
    """
    Generate summary statistics for each cluster.
    
    Parameters
    ----------
    rfm : pd.DataFrame
        RFM DataFrame with Cluster column.
    
    Returns
    -------
    pd.DataFrame
        Summary statistics per cluster.
    """
    summary = rfm.groupby('Cluster').agg({
        'Recency': ['mean', 'median', 'std'],
        'Frequency': ['mean', 'median', 'std'],
        'Monetary': ['mean', 'median', 'std']
    }).round(2)
    
    # Add customer counts
    counts = rfm.groupby('Cluster').size()
    percentages = (counts / len(rfm) * 100).round(2)
    
    summary[('Count', 'n')] = counts
    summary[('Count', '%')] = percentages
    
    return summary


def predict_customer_segment(recency: int,
                             frequency: int,
                             monetary: float,
                             scaler: StandardScaler,
                             kmeans_model: KMeans) -> int:
    """
    Predict the cluster/segment for a new customer.
    
    Parameters
    ----------
    recency : int
        Days since last purchase.
    frequency : int
        Number of transactions.
    monetary : float
        Total spending amount.
    scaler : StandardScaler
        Fitted scaler object.
    kmeans_model : KMeans
        Trained K-Means model.
    
    Returns
    -------
    int
        Predicted cluster number.
    
    Examples
    --------
    >>> segment = predict_customer_segment(30, 5, 3000, scaler, kmeans)
    >>> print(f"Predicted Segment: {segment}")
    Predicted Segment: 0
    """
    # Create feature array
    new_customer = np.array([[recency, frequency, monetary]])
    
    # Scale features
    new_customer_scaled = scaler.transform(new_customer)
    
    # Predict cluster
    cluster = kmeans_model.predict(new_customer_scaled)
    
    return cluster[0]


def plot_cluster_profiles(rfm: pd.DataFrame,
                          save_path: Optional[str] = None) -> None:
    """
    Visualize cluster characteristics with bar charts.
    
    Parameters
    ----------
    rfm : pd.DataFrame
        RFM DataFrame with Cluster column.
    save_path : str, optional
        Path to save the figure.
    """
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']
    
    # Cluster distribution
    cluster_counts = rfm['Cluster'].value_counts().sort_index()
    axes[0, 0].bar(cluster_counts.index, cluster_counts.values, color=colors, edgecolor='white')
    axes[0, 0].set_xlabel('Cluster', fontsize=11)
    axes[0, 0].set_ylabel('Number of Customers', fontsize=11)
    axes[0, 0].set_title('Customer Distribution by Cluster', fontsize=13, fontweight='bold')
    for i, v in enumerate(cluster_counts.values):
        axes[0, 0].text(i, v + 20, str(v), ha='center', fontweight='bold')
    
    # Calculate means
    cluster_means = rfm.groupby('Cluster')[['Recency', 'Frequency', 'Monetary']].mean()
    
    # Recency by cluster
    axes[0, 1].bar(cluster_means.index, cluster_means['Recency'], color=colors, edgecolor='white')
    axes[0, 1].set_xlabel('Cluster', fontsize=11)
    axes[0, 1].set_ylabel('Average Recency (Days)', fontsize=11)
    axes[0, 1].set_title('Average Recency by Cluster', fontsize=13, fontweight='bold')
    
    # Frequency by cluster
    axes[1, 0].bar(cluster_means.index, cluster_means['Frequency'], color=colors, edgecolor='white')
    axes[1, 0].set_xlabel('Cluster', fontsize=11)
    axes[1, 0].set_ylabel('Average Frequency', fontsize=11)
    axes[1, 0].set_title('Average Frequency by Cluster', fontsize=13, fontweight='bold')
    
    # Monetary by cluster
    axes[1, 1].bar(cluster_means.index, cluster_means['Monetary'], color=colors, edgecolor='white')
    axes[1, 1].set_xlabel('Cluster', fontsize=11)
    axes[1, 1].set_ylabel('Average Monetary (£)', fontsize=11)
    axes[1, 1].set_title('Average Monetary Value by Cluster', fontsize=13, fontweight='bold')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Figure saved to {save_path}")
    
    plt.show()


def plot_3d_clusters(rfm: pd.DataFrame,
                     save_path: Optional[str] = None) -> None:
    """
    Create 3D scatter plot of customer segments.
    
    Parameters
    ----------
    rfm : pd.DataFrame
        RFM DataFrame with Cluster column.
    save_path : str, optional
        Path to save the figure.
    """
    from mpl_toolkits.mplot3d import Axes3D
    
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']
    n_clusters = rfm['Cluster'].nunique()
    
    for cluster in range(n_clusters):
        cluster_data = rfm[rfm['Cluster'] == cluster]
        ax.scatter(
            cluster_data['Recency'],
            cluster_data['Frequency'],
            cluster_data['Monetary'],
            c=colors[cluster],
            label=f'Cluster {cluster}',
            alpha=0.6,
            s=30
        )
    
    ax.set_xlabel('Recency (Days)', fontsize=10)
    ax.set_ylabel('Frequency', fontsize=10)
    ax.set_zlabel('Monetary (£)', fontsize=10)
    ax.set_title('3D Visualization of Customer Segments', fontsize=14, fontweight='bold')
    ax.legend(loc='upper left')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Figure saved to {save_path}")
    
    plt.show()


def export_segments(rfm: pd.DataFrame,
                    filepath: str) -> None:
    """
    Export segmented customer data to CSV.
    
    Parameters
    ----------
    rfm : pd.DataFrame
        RFM DataFrame with Cluster column.
    filepath : str
        Output file path.
    """
    rfm_export = rfm.reset_index()
    rfm_export.to_csv(filepath, index=False)
    print(f"Exported {len(rfm_export):,} customer segments to {filepath}")


if __name__ == "__main__":
    print("RFM Analysis Module")
    print("Use: from rfm_analysis import calculate_rfm, segment_customers")
